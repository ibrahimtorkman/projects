#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/* check if number is power of two */
int checkPowerOfTwo( int num );

//==============================================================================

int checkPowerOfTwo( int num )
{
    int temp=num;
    if( num<=0 )
        return 0;
    int the_power=0;
    while( num!=1 )
    {
        if( num%2 == 1 )
            return 0;
        num/=2;
        the_power++;
    }
    printf("The number %d is a power of 2: %d = 2^%d\n", temp ,temp ,the_power);
    return the_power;
}

int main()
{
    printf("Enter size of input:\n");
    int size_of_input=0;
    scanf( "%d" , &size_of_input );
    if( size_of_input <=0 )
    {
        printf("Invalid size\n");
        return(0);
    }
    printf("Enter numbers:\n");

    int* numbers = malloc(sizeof(*numbers) * size_of_input);

    for(int i=0; i<size_of_input; i++)
    {
        if ( (scanf("%d", &numbers[i]) != 1) )
        {
            free(numbers);
            printf("Invalid number\n");
            return 0;
        }
    }

    int total_exponent_sum=0;
    for( int k=0 ; k<size_of_input ; k++ )
    {
        total_exponent_sum += checkPowerOfTwo(numbers[k]);
    }
    printf("Total exponent sum is %d\n", total_exponent_sum);
    free(numbers);
    return 0;
}

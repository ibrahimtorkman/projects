#include "Vehicle.h"

using namespace MtmParkingLot;

Vehicle::Vehicle(VehicleType type, LicensePlate vehicle_id, Time time) :
            vehicle_type(type), license_plate(vehicle_id), entrance_time(time), ticketed(false){
}

Vehicle::Vehicle(LicensePlate vehicle_id) : license_plate(vehicle_id){
}

bool Vehicle::operator==(const Vehicle &other_vehicle) const {
    return (license_plate==other_vehicle.license_plate);
}

VehicleType Vehicle::GetVehicleType() const {
    return vehicle_type;
}

Time Vehicle::GetEntranceTime() const {
    return entrance_time;
}

bool Vehicle::checkIfTicketed() const {
    return ticketed;
}

LicensePlate Vehicle::getLicensePlate() const{
    return license_plate;
}

void Vehicle::setTicket() {
    if(!ticketed){
        ticketed=true;
    }
}
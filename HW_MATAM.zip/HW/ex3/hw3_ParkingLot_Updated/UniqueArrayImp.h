#ifndef EX3_SOL_LIBRARY_H
#define EX3_SOL_LIBRARY_H


template <class Element,class Compare>
static bool checkContains(Element** element_array, const Element& element, unsigned int& index, Compare compare, unsigned int max_size){
    for(unsigned int i = 0; i < max_size; i++){
        if( !*(element_array+i) ){
            continue;
        }
        if(compare(**(element_array+i), element)) {
            index = i;
            return true;
        }
    }
    return false;
}

template <class Element, class Compare>
UniqueArray<Element, Compare>::UniqueArray(unsigned int size) : data(new Element*[size]), compare(Compare()), max_size(size), counter(0){
    for (unsigned int i = 0; i < size; ++i) {
        data[i] = NULL;
    }
}

template <class Element, class Compare>
UniqueArray<Element, Compare>::UniqueArray(const UniqueArray& other) :
    data(new Element*[other.max_size]), compare(other.compare), max_size(other.max_size), counter(other.counter){
    for (int i = 0 ; i < max_size; i++) {
        if( !*(other.data+i )){
            data[i] = NULL;
            continue;
        }
        Element* temp = new Element(**(other.data+i));
        data[i] = temp;
    }
}

template <class Element, class Compare>
UniqueArray<Element, Compare>::~UniqueArray(){
    for (int i = 0 ; i < max_size; ++i) {
        delete data[i];
    }
    delete[] data;
}


template <class Element, class Compare>
unsigned int UniqueArray<Element, Compare>::insert(const Element& element){
    unsigned int index = 0;
    if(checkContains<Element, Compare>(data, element, index, compare, max_size)) {
        return index;
    } else if( getCount() >= max_size ){
        throw UniqueArrayIsFullException();
    } else{
        for(index = 0; index < max_size; index++){
            if( !data[index] ){
                break;
            }
        }
        data[index] = new Element(element);
        counter++;
        return index;
    }
}

template <class Element, class Compare>
bool UniqueArray<Element, Compare>::getIndex(const Element& element, unsigned int& index) const{
    return checkContains<Element, Compare>(data, element, index, compare, max_size);
}

template <class Element, class Compare>
const Element* UniqueArray<Element, Compare>::operator[] (const Element& element) const{
    unsigned int i=0;
    if(checkContains<Element, Compare>(data, element, i, compare, max_size)){
        return data[i];
    }
    return NULL;
}

template <class Element, class Compare>
Element* UniqueArray<Element, Compare>::getElementByIndex(unsigned int index) {
    return data[index];
}

template <class Element, class Compare>
const Element* UniqueArray<Element, Compare>::getElementByIndex(unsigned int index) const {
    return data[index];
}

template <class Element, class Compare>
bool UniqueArray<Element, Compare>::remove(const Element& element){
    if(getCount() <= 0)
        return false;
    unsigned int index = 0;
    if(checkContains<Element, Compare>(data, element, index, compare, max_size)){
        delete data[index];
        data[index] = NULL;
        counter--;
        return true;
    }
    return false;
}

template <class Element, class Compare>
unsigned int UniqueArray<Element, Compare>::getCount() const{
    return counter;
}

template <class Element, class Compare>
unsigned int UniqueArray<Element, Compare>::getSize() const{
    return  max_size;
}

template <class Element, class Compare>
UniqueArray<Element, Compare> UniqueArray<Element, Compare>::filter(const Filter& f) const {
    UniqueArray new_array(this->max_size);
    for (int i = 0; i < this->max_size; ++i) {
        if( f(*((this->data)[i])) ){
            Element* temp = new Element(**((this->data)+i));
            new_array.data[i] = temp;
            new_array.counter++;
        }
    }
    return new_array;
}

template <class Element, class Compare>
void UniqueArray<Element,Compare>::removeByIndex(unsigned int index) {
    delete data[index];
    data[index] = NULL;
    counter--;
}

#endif
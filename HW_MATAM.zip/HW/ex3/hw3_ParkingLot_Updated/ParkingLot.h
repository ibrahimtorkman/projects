#ifndef MTMPARKINGLOT_PARKINGLOT_H
#define MTMPARKINGLOT_PARKINGLOT_H

#include "ParkingLotTypes.h"
#include "ParkingSpot.h"
#include "ParkingLotPrinter.h"
#include "Time.h"
#include "UniqueArray.h"
#include "Vehicle.h"
#include <algorithm>
#include <vector>

#define EXIST true
#define DOES_NOT_EXIST false

enum Prices{
    INSPECTOR_TICKET_PRICE = 250,
    MOTOR_FIRST_HOUR_PRICE = 10,
    MOTOR_HOUR_PRICE = 5,
    MOTOR_MAX_PRICE = 35,
    CAR_FIRST_HOUR_PRICE = 20,
    CAR_HOUR_PRICE = 10,
    CAR_MAX_PRICE = 70,
    HANDICAPPED_FEE_PRICE = 15,
    NO_FEE = 0,
};
enum SpecialHours{
    MAX_HOURS_FEE = 6,
    FULL_DAY = 24
};

namespace MtmParkingLot {
    using std::cout;
    using std::vector;
    using namespace ParkingLotUtils;
    using std::ostream;

    class ParkingLot {
    public:
        explicit ParkingLot(unsigned int parkingBlockSizes[]);
        ~ParkingLot();
        ParkingResult enterParking(VehicleType vehicleType, LicensePlate licensePlate, Time entranceTime);
        ParkingResult exitParking(LicensePlate& licensePlate, Time exitTime);
        ParkingResult getParkingSpot(LicensePlate licensePlate, ParkingSpot &parkingSpot) const;
        void inspectParkingLot(Time inspectionTime);
        friend ostream &operator<<(ostream &os, const ParkingLot &parkingLot);

        class compareSpotFunc {
        public:
            bool operator()(const ParkingSpot &spot1, const ParkingSpot &spot2){
                return spot1 < spot2;
            }
        };

    private:
        UniqueArray<Vehicle, Vehicle::CompareVehicle> motorcycle_array;
        UniqueArray<Vehicle, Vehicle::CompareVehicle> handicapped_array;
        UniqueArray<Vehicle, Vehicle::CompareVehicle> cars_array;

        ParkingResult checkSpot(UniqueArray<Vehicle, Vehicle::CompareVehicle>& array, const Vehicle& vehicle, VehicleType array_type) const;
        ParkingResult checkSpot(UniqueArray<Vehicle, Vehicle::CompareVehicle>& array, unsigned int index,
                                const LicensePlate& licensePlate, Time exit_time, VehicleType array_type) const;
        bool checkExistence(const Vehicle& vehicle, VehicleType &array_type, unsigned int &index) const;
        unsigned int priceCalculator(Time::Hour time, VehicleType type, bool ticketed) const;
        void putTickets(UniqueArray<Vehicle,Vehicle::CompareVehicle>& array, unsigned int& counter, Time inspectionTime) const;
        void FillVector(ostream &os, UniqueArray<Vehicle, Vehicle::CompareVehicle> array, VehicleType array_type,vector<ParkingSpot>& Vector)const;
    };
}

#endif //MTMPARKINGLOT_PARKINGLOT_H
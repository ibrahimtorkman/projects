#include "ParkingLot.h"

namespace MtmParkingLot {
    ParkingResult ParkingLot::checkSpot(UniqueArray<Vehicle, Vehicle::CompareVehicle>& array, const Vehicle &vehicle,
                                        VehicleType array_type) const {
        unsigned int index = 0;
        VehicleType temp_array_type = MOTORBIKE;
        if (checkExistence(vehicle, temp_array_type, index)) {
            if(temp_array_type==CAR) {
                ParkingLotPrinter::printVehicle(cout, cars_array.getElementByIndex(index)->GetVehicleType(),
                                                vehicle.getLicensePlate(),
                                                cars_array.getElementByIndex(index)->GetEntranceTime());
            }
            if(temp_array_type==MOTORBIKE) {
                ParkingLotPrinter::printVehicle(cout, motorcycle_array.getElementByIndex(index)->GetVehicleType(),
                                                vehicle.getLicensePlate(),
                                                motorcycle_array.getElementByIndex(index)->GetEntranceTime());
            }
            else if(temp_array_type==HANDICAPPED) {
                ParkingLotPrinter::printVehicle(cout, handicapped_array.getElementByIndex(index)->GetVehicleType(),
                                                vehicle.getLicensePlate(),
                                                handicapped_array.getElementByIndex(index)->GetEntranceTime());
            }

            ParkingSpot spot(temp_array_type, index);
            ParkingLotPrinter::printEntryFailureAlreadyParked(cout, spot);
            return VEHICLE_ALREADY_PARKED;
        }
        if (array.getCount() >= array.getSize()) {
            return NO_EMPTY_SPOT;
        }
        index = array.insert(vehicle);
        ParkingSpot spot(array_type, index);
        ParkingLotPrinter::printVehicle(cout, vehicle.GetVehicleType(), vehicle.getLicensePlate(),
                                        vehicle.GetEntranceTime());
        ParkingLotPrinter::printEntrySuccess(cout, spot);
        return SUCCESS;
    }

    bool ParkingLot::checkExistence(const Vehicle &vehicle, VehicleType &array_type, unsigned int &index) const {
        if (motorcycle_array.getIndex(vehicle, index)) {
            array_type = MOTORBIKE;
            return EXIST;
        }
        if (cars_array.getIndex(vehicle, index)) {
            array_type = CAR;
            return EXIST;
        }
        if (handicapped_array.getIndex(vehicle, index)) {
            array_type = HANDICAPPED;
            return EXIST;
        }
        return DOES_NOT_EXIST;
    }

    ParkingResult ParkingLot::checkSpot(UniqueArray<Vehicle, Vehicle::CompareVehicle> &array, unsigned int index,
                                        const LicensePlate &licensePlate, Time exit_time,
                                        VehicleType array_type) const {
        ParkingLotPrinter::printVehicle(cout, array.getElementByIndex(index)->GetVehicleType(), licensePlate,
                                        array.getElementByIndex(index)->GetEntranceTime());
        ParkingSpot spot(array_type, index);
        Time::Hour total_time = (exit_time - array.getElementByIndex(index)->GetEntranceTime()).toHours();
        unsigned int bill = priceCalculator(total_time, array.getElementByIndex(index)->GetVehicleType(),
                                            array.getElementByIndex(index)->checkIfTicketed());
        ParkingLotPrinter::printExitSuccess(cout, spot, exit_time, bill);
        array.removeByIndex(index);
        return SUCCESS;
    }

    unsigned int ParkingLot::priceCalculator(Time::Hour time, VehicleType type, bool ticketed) const{
        if (time == 0) {
            return Prices::NO_FEE;
        }
        if (type == HANDICAPPED) {
            if (ticketed) {
                return Prices::HANDICAPPED_FEE_PRICE + Prices::INSPECTOR_TICKET_PRICE;
            }
            return Prices::HANDICAPPED_FEE_PRICE;
        }
        if (type == CAR) {
            if (ticketed) {
                return Prices::CAR_MAX_PRICE + Prices::INSPECTOR_TICKET_PRICE;
            }
            if (time >= MAX_HOURS_FEE) {
                return Prices::CAR_MAX_PRICE;
            }
            return Prices::CAR_FIRST_HOUR_PRICE + (time-1) * Prices::CAR_HOUR_PRICE;
        }
        if (ticketed) {
            return Prices::MOTOR_MAX_PRICE + Prices::INSPECTOR_TICKET_PRICE;
        }
        if (time >= MAX_HOURS_FEE) {
            return Prices::MOTOR_MAX_PRICE;
        }
        return Prices::MOTOR_FIRST_HOUR_PRICE + (time-1) * Prices::MOTOR_HOUR_PRICE;
    }

    void ParkingLot::putTickets(UniqueArray<Vehicle, Vehicle::CompareVehicle> &array, unsigned int &counter,
                                Time inspectionTime) const{
        for (unsigned int i = 0; i < array.getSize(); i++) {
            if (array.getElementByIndex(i)) {
                if ((inspectionTime - array.getElementByIndex(i)->GetEntranceTime()).toHours() > FULL_DAY) {
                    if (!array.getElementByIndex(i)->checkIfTicketed()) {
                        array.getElementByIndex(i)->setTicket();
                        counter++;
                    }
                }
            }
        }
    }

    ParkingLot::ParkingLot(unsigned int *parkingBlockSizes) : motorcycle_array(parkingBlockSizes[MOTORBIKE]),
                                                              handicapped_array(parkingBlockSizes[HANDICAPPED]),
                                                              cars_array(parkingBlockSizes[CAR]) {

    }

    ParkingLot::~ParkingLot() = default;

    ParkingResult ParkingLot::enterParking(VehicleType vehicleType, LicensePlate licensePlate, Time entranceTime) {
        Vehicle vehicle(vehicleType, licensePlate, entranceTime);
        ParkingResult temp_result;
        if (vehicleType == HANDICAPPED && handicapped_array.getSize() != 0) {
            ParkingResult temp = checkSpot(handicapped_array, vehicle, HANDICAPPED);
            if (temp == NO_EMPTY_SPOT) {
                if (checkSpot(cars_array, vehicle, CAR) == NO_EMPTY_SPOT) {
                    ParkingLotPrinter::printVehicle(cout, vehicleType, licensePlate, entranceTime);
                    ParkingLotPrinter::printEntryFailureNoSpot(cout);
                    return NO_EMPTY_SPOT;
                }
            }
            return temp;
        }
        if (vehicleType == MOTORBIKE) {
            temp_result = checkSpot(motorcycle_array, vehicle, MOTORBIKE);
            if (temp_result == NO_EMPTY_SPOT) {
                ParkingLotPrinter::printVehicle(cout, vehicleType, licensePlate, entranceTime);
                ParkingLotPrinter::printEntryFailureNoSpot(cout);
                return temp_result;
            }
            return temp_result;
        }
        temp_result = checkSpot(cars_array, vehicle, CAR);
        if (temp_result == NO_EMPTY_SPOT) {
            ParkingLotPrinter::printVehicle(cout, vehicleType, licensePlate, entranceTime);
            ParkingLotPrinter::printEntryFailureNoSpot(cout);
            return temp_result;
        }
        return temp_result;
    }


    ParkingResult ParkingLot::exitParking(LicensePlate &licensePlate, Time exitTime) {
        Vehicle temp(licensePlate);
        VehicleType array_type = MOTORBIKE;
        unsigned int index = 0;
        if (checkExistence(temp, array_type, index)) {
            if (array_type == MOTORBIKE) {
                return checkSpot(motorcycle_array, index, licensePlate, exitTime, MOTORBIKE);
            }
            if (array_type == HANDICAPPED) {
                return checkSpot(handicapped_array, index, licensePlate, exitTime, HANDICAPPED);
            }
            return checkSpot(cars_array, index, licensePlate, exitTime, CAR);
        }
        ParkingLotPrinter::printExitFailure(cout, licensePlate);
        return VEHICLE_NOT_FOUND;
    }

    ParkingResult ParkingLot::getParkingSpot(LicensePlate licensePlate, ParkingSpot &parkingSpot) const {
        Vehicle temp(licensePlate);
        VehicleType array_type = MOTORBIKE;
        unsigned int index = 0;
        if (checkExistence(temp, array_type, index)) {
            ParkingSpot temp_spot(array_type, index);
            parkingSpot = temp_spot;
            return SUCCESS;
        }
        return VEHICLE_NOT_FOUND;
    }

    void ParkingLot::inspectParkingLot(Time inspectionTime) {
        unsigned int counter = 0;
        putTickets(motorcycle_array, counter, inspectionTime);
        putTickets(cars_array, counter, inspectionTime);
        putTickets(handicapped_array, counter, inspectionTime);
        ParkingLotPrinter::printInspectionResult(cout, inspectionTime, counter);
    }

    ostream &operator<<(ostream &os, const MtmParkingLot::ParkingLot &parkingLot){
        ParkingLotPrinter::printParkingLotTitle(os);
        vector<ParkingSpot> vector;
        parkingLot.FillVector(os, parkingLot.motorcycle_array, MOTORBIKE, vector);
        parkingLot.FillVector(os, parkingLot.handicapped_array, HANDICAPPED, vector);
        parkingLot.FillVector(os, parkingLot.cars_array, CAR, vector);
        std::sort(vector.begin(), vector.end(), ParkingLot::compareSpotFunc());
        for (size_t i = 0; i < vector.size(); i++) {
            unsigned int place=vector.at(i).getParkingNumber();
            VehicleType array_type=vector.at(i).getParkingBlock();
            if(array_type==MOTORBIKE){
                ParkingLotPrinter::printVehicle(os,parkingLot.motorcycle_array.getElementByIndex(place)->GetVehicleType(),
                                                 parkingLot.motorcycle_array.getElementByIndex(place)->getLicensePlate(),
                                                 parkingLot.motorcycle_array.getElementByIndex(place)->GetEntranceTime());
            }
            if(array_type==HANDICAPPED){
                ParkingLotPrinter::printVehicle(os,parkingLot.handicapped_array.getElementByIndex(place)->GetVehicleType(),
                                                parkingLot.handicapped_array.getElementByIndex(place)->getLicensePlate(),
                                                parkingLot.handicapped_array.getElementByIndex(place)->GetEntranceTime());
            }
            if(array_type==CAR){
                ParkingLotPrinter::printVehicle(os,parkingLot.cars_array.getElementByIndex(place)->GetVehicleType(),
                                                parkingLot.cars_array.getElementByIndex(place)->getLicensePlate(),
                                                parkingLot.cars_array.getElementByIndex(place)->GetEntranceTime());
            }
            ParkingLotPrinter::printParkingSpot(os, vector.at(i));
        }
        return os;
    }

    void ParkingLot::FillVector(ostream &os, UniqueArray<Vehicle, Vehicle::CompareVehicle> array, VehicleType array_type,vector<ParkingSpot>& Vector)const {
        for (unsigned int i = 0; i < array.getSize(); i++) {
            if (array.getElementByIndex(i)) {
                ParkingSpot temp(array_type, i);
                Vector.push_back(temp);
            }
        }
    }
}
#ifndef MTMPARKINGLOT_VEHICLE_H
#define MTMPARKINGLOT_VEHICLE_H

#include "Time.h"
#include "ParkingSpot.h"
#include "ParkingLotTypes.h"
#include <cstring>

namespace MtmParkingLot{
    using namespace ParkingLotUtils;
    class Vehicle{
        VehicleType vehicle_type;
        LicensePlate license_plate;
        Time entrance_time;
        bool ticketed;
    public:
        Vehicle(VehicleType type, LicensePlate vehicle_id, Time time);
        explicit Vehicle(LicensePlate vehicle_id);
        bool operator==(const Vehicle &other_vehicle) const;
        VehicleType GetVehicleType() const;
        Time GetEntranceTime() const;
        LicensePlate getLicensePlate() const;
        void setTicket();
        bool checkIfTicketed() const;
        class CompareVehicle {
        public:
            bool operator()(const Vehicle &vehicle1, const Vehicle &vehicle2){
                return vehicle1.license_plate == vehicle2.license_plate;
            }
        };
    };
}
#endif //MTMPARKINGLOT_VEHICLE_H
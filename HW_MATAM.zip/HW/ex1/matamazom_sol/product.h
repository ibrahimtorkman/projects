#ifndef PRODUCT_PRODUCT_H
#define PRODUCT_PRODUCT_H

#include "matamazom.h"
#include "amount_set.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define EPSILON 0.001

typedef struct product_t *Product;

/** a function for creating a new product. */
Product createProductFunction(const unsigned int id, const char *name, double profits, const MatamazomAmountType amountType,
                              const MtmProductData customData, MtmCopyData copyDataFunction, MtmFreeData freeDataFunction,
                              MtmGetProductPrice getProductPriceFunction);

/** a  function for coping a existing product. */
Product copyProductFunction(Product);

/** a function for deallocating an existing product. */
void freeProductFunction(Product to_delete);

/**
 * a function used to identify equal products.
 * This function should return:
 *     A positive integer if the first product's id is greater;
 *     0 if they're equal;
 *     A negative integer if the second product's id is greater.
 */
int compareProductFunction(Product product1, Product product2);

/** a function that checks if the first letter of the name is valid. */
bool isValidName(char letter);

/** a function for checking if the amount is suitable for the amount type. */
bool checkAmount(const MatamazomAmountType amountType, const double amount);

/** a function for findinga product in a set from it's id. */
Product getProduct(AmountSet set, unsigned int id);

/** a function that returns the product's id. */
unsigned int getProductId(Product product);

/** a function that returns the product's name. */
char* getProductName(Product product);

/** a function that returns the product's profits. */
double getProductProfits(Product product);

/** a function that returns the product's amount type. */
MatamazomAmountType getProductAmountType(Product product);

/** a function that returns the product's custom data. */
MtmProductData getProductCustomData(Product product);

/** a function for changing the product's profits. */
bool changeProductProfits(Product product, double profits);

/** a function for calculating the price of the required amount from a product. */
double productPrice(Product product, double amount);


#endif //PRODUCT_PRODUCT_H
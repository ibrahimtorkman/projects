#include "order.h"

struct order_t{
    unsigned int order_id;
    AmountSet order_products;
};

Order createOrderFunction(unsigned int id){
    Order new_order = malloc(sizeof(*new_order));
    if ( !new_order ) {
        return NULL;
    }
    new_order->order_products = asCreate((CopyASElement) &copyProductFunction,
                                         (FreeASElement) &freeProductFunction,
                                         (CompareASElements) &compareProductFunction);
    if( !new_order->order_products ){
        free(new_order);
        return NULL;
    }
    new_order->order_id = id;
    return new_order;
}

void freeOrderFunction(Order to_delete){
    if ( !to_delete ){
        return;
    }
    asDestroy(to_delete->order_products);
    free(to_delete);
}

Order copyOrderFunction(Order original_order){
    if ( !original_order ){
        return NULL;
    }
    Order new_order = malloc(sizeof(*new_order));
    if ( !new_order ){
        return NULL;
    }
    new_order->order_id = original_order->order_id;
    new_order->order_products = asCopy(original_order->order_products);
    if( !(new_order->order_products) ){
        freeOrderFunction(new_order);
        return NULL;
    }
    return new_order;
}

int compareOrderFunction(Order order1, Order order2){
    return (int)order1->order_id - (int)order2->order_id;
}

Order getOrder(Set set, unsigned int id){
    SET_FOREACH(Order, iterator, set){
        if( iterator->order_id==id ){
            return iterator;
        }
    }
    return NULL;
}

AmountSet getOrderProducts(Order order){
    if( !order ){
        return NULL;
    }
    return order->order_products;
}
#include "product.h"

struct product_t{
    unsigned int product_id;
    char *name;
    double profits;
    MtmProductData  customData;
    MatamazomAmountType amountType;
    MtmCopyData  copyData;
    MtmFreeData freeData;
    MtmGetProductPrice productPrice;
};

Product createProductFunction(const unsigned int id, const char *name, double profits, const MatamazomAmountType amountType,
                              const MtmProductData customData, MtmCopyData copyDataFunction, MtmFreeData freeDataFunction,
                              MtmGetProductPrice getProductPriceFunction){
    if( !copyDataFunction || !freeDataFunction || !getProductPriceFunction ){
        return NULL;
    }
    Product new_product = malloc(sizeof(*new_product));
    if( !new_product ){
        return NULL;
    }
    new_product->name = malloc(strlen(name)+1);
    if( !new_product->name ){
        free(new_product);
        return NULL;
    }
    new_product->product_id = id;
    strcpy(new_product->name, name);
    new_product->profits = profits;
    new_product->amountType = amountType;
    new_product->copyData = copyDataFunction;
    new_product->customData = new_product->copyData(customData);
    new_product->freeData = freeDataFunction;
    new_product->productPrice = getProductPriceFunction;
    return new_product;
}

Product copyProductFunction(Product original_product){
    if( !original_product ){
        return NULL;
    }
    Product new_product = malloc(sizeof(*new_product));
    if( !new_product ){
        return NULL;
    }
    new_product->name = malloc(strlen(original_product->name)+1);
    if( !new_product->name ){
        free(new_product);
        return NULL;
    }
    new_product->product_id = original_product->product_id;
    strcpy(new_product->name, original_product->name);
    new_product->profits = original_product->profits;
    new_product->amountType = original_product->amountType;
    new_product->copyData = original_product->copyData;
    new_product->customData = new_product->copyData(original_product->customData);
    new_product->freeData = original_product->freeData;
    new_product->productPrice = original_product->productPrice;
    return new_product;
}

void freeProductFunction(Product to_delete){
    if( !to_delete ){
        return;
    }
    to_delete->freeData(to_delete->customData);
    free(to_delete->name);
    free(to_delete);
}

int compareProductFunction(Product product1, Product product2){
    return (int)product1->product_id - (int)product2->product_id;
}

Product getProduct(AmountSet set, unsigned int id){
    AS_FOREACH(Product, iterator, set){
        if( iterator->product_id==id ){
            return iterator;
        }
    }
    return NULL;
}

static inline double absoluteValue(double number){
    return number > 0 ? number : -number;
}

bool checkAmount(const MatamazomAmountType amountType, const double amount){
    double absolute = absoluteValue(amount);
    double difference = absolute - (int)absolute;
    if( amountType==MATAMAZOM_INTEGER_AMOUNT ){
        if( (0<=difference && difference<=EPSILON) || (1-EPSILON<=difference && difference<=1) ){
            return true;
        }else{
            return false;
        }
    }
    if( amountType==MATAMAZOM_HALF_INTEGER_AMOUNT ){
        if( (0<=difference && difference<=EPSILON) || (1-EPSILON<=difference && difference<=1) ||
            (0.5-EPSILON<=difference && difference<=0.5+EPSILON) ){
            return true;
        }else{
            return false;
        }
    }else{return true;}
}

unsigned int getProductId(Product product){
    if( !product ){
        return 0;
    }
    return product->product_id;
}

char* getProductName(Product product){
    if( !product ){
        return NULL;
    }
    return product->name;
}

double getProductProfits(Product product){
    if( !product ){
        return -1;
    }
    return product->profits;
}

MatamazomAmountType getProductAmountType(Product product){
    return product->amountType;
}

MtmProductData getProductCustomData(Product product){
    if( !product ){
        return NULL;
    }
    return  product->customData;
}

bool changeProductProfits(Product product, double profits){
    if( !product ){
        return NULL;
    }
    if( profits<0 ){
        return false;
    }
    product->profits = profits;
    return true;
}

double productPrice(Product product, double amount){
    double price = product->productPrice(product->customData, amount);
    return price;
}
bool isValidName(char letter){
    if( (letter=='\0') || (!(letter>='a' && letter<='z') && !(letter>='A' && letter<='Z') && !(letter>=0 && letter<=9)) ){
        return false;
    }
    return true;
}
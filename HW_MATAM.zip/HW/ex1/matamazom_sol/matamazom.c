#include "matamazom.h"
#include "product.h"
#include "order.h"
#include "amount_set.h"
#include "set.h"
#include "matamazom_print.h"
#include <stdio.h>
#include <stdlib.h>

struct Matamazom_t{
    AmountSet container;
    Set orders;
    unsigned int orders_id_counter;
};

Matamazom matamazomCreate(){
    Matamazom new_matamazom = malloc(sizeof(*new_matamazom));
    if( !new_matamazom ){
        return NULL;
    }
    new_matamazom->container = asCreate((CopyASElement) copyProductFunction,
                                        (FreeASElement) freeProductFunction,
                                        (CompareASElements) compareProductFunction);
    if( !new_matamazom->container ){
        free(new_matamazom);
        return NULL;
    }
    new_matamazom->orders = setCreate((copySetElements) copyOrderFunction,
                                      (freeSetElements) freeOrderFunction,
                                      (compareSetElements) compareOrderFunction);
    if( !new_matamazom->orders ){
        asDestroy(new_matamazom->container);
        free(new_matamazom);
        return NULL;
    }
    new_matamazom->orders_id_counter = 1;
    return new_matamazom;
}

void matamazomDestroy(Matamazom matamazom){
    if( !matamazom ){
        return;
    }
    asDestroy(matamazom->container);
    setDestroy(matamazom->orders);
    free(matamazom);
}

MatamazomResult mtmNewProduct(Matamazom matamazom, const unsigned int id, const char *name,
                              const double amount, const MatamazomAmountType amountType,
                              const MtmProductData customData, MtmCopyData copyData,
                              MtmFreeData freeData, MtmGetProductPrice prodPrice){
    if( !matamazom || !name  || !customData || !copyData || !freeData || !prodPrice ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    if( amount<0 ){
        return MATAMAZOM_INVALID_AMOUNT;
    }
    if( !isValidName(name[0]) ){
        return MATAMAZOM_INVALID_NAME;
    }
    if( !checkAmount(amountType, amount) ) {
        return MATAMAZOM_INVALID_AMOUNT;
    }
    Product new_product = createProductFunction(id, name, 0, amountType, customData, copyData, freeData, prodPrice);
    if(asRegister(matamazom->container, new_product)==AS_ITEM_ALREADY_EXISTS) {
        return MATAMAZOM_PRODUCT_ALREADY_EXIST;
    }
    if( mtmChangeProductAmount(matamazom, id, amount)==MATAMAZOM_INVALID_AMOUNT ){
        mtmClearProduct(matamazom, id);
        freeProductFunction(new_product);
        return MATAMAZOM_INVALID_AMOUNT;
    }
    freeProductFunction(new_product);
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmChangeProductAmount(Matamazom matamazom, const unsigned int id, const double amount){
    if( !matamazom ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    Product temp_product = getProduct(matamazom->container, id);
    if( !temp_product ){
        return MATAMAZOM_PRODUCT_NOT_EXIST;
    }
    double amount_saver = 0;
    asGetAmount(matamazom->container, temp_product, &amount_saver);
    if( !checkAmount(getProductAmountType(temp_product), amount) ){
        return MATAMAZOM_INVALID_AMOUNT;
    }
    AmountSetResult result = asChangeAmount(matamazom->container, temp_product, amount);
    if( result==AS_INSUFFICIENT_AMOUNT ){
        return MATAMAZOM_INSUFFICIENT_AMOUNT;
    }
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmClearProduct(Matamazom matamazom, const unsigned int id){
    if( !matamazom ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    Product temporary_product = getProduct(matamazom->container, id);
    if( !temporary_product ){
        return MATAMAZOM_PRODUCT_NOT_EXIST;
    }
    SET_FOREACH(Order, iterator, matamazom->orders){
        Product temp_product_in_order = getProduct(getOrderProducts(iterator), id);
        if( temp_product_in_order ){
            asDelete(getOrderProducts(iterator), temp_product_in_order);
        }
    }
    if( asDelete(matamazom->container, temporary_product)==AS_SUCCESS ){
        return MATAMAZOM_SUCCESS;
    }
    return MATAMAZOM_PRODUCT_NOT_EXIST;
}

unsigned int mtmCreateNewOrder(Matamazom matamazom){
    if( !matamazom ){
        return 0;
    }
    Order new_order = createOrderFunction(matamazom->orders_id_counter);
    matamazom->orders_id_counter += 1;
    setAdd(matamazom->orders, new_order);
    freeOrderFunction(new_order);
    return matamazom->orders_id_counter-1;
}

MatamazomResult mtmChangeProductAmountInOrder(Matamazom matamazom, const unsigned int orderId,
                                              const unsigned int productId, const double amount){
    if( !matamazom ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    Order temp_order = getOrder(matamazom->orders, orderId);
    if( !temp_order ){
        return MATAMAZOM_ORDER_NOT_EXIST;
    }
    Product temp_product_in_container = getProduct(matamazom->container, productId);
    if( !temp_product_in_container ){
        return MATAMAZOM_PRODUCT_NOT_EXIST;
    }
    if( amount==0 ){
        return MATAMAZOM_SUCCESS;
    }
    if( checkAmount(getProductAmountType(temp_product_in_container), amount)==false ){
        return MATAMAZOM_INVALID_AMOUNT;
    }
    Product temp_product_in_order = getProduct(getOrderProducts(temp_order), productId);
    if( !temp_product_in_order ){
        if( amount<0 ){
            return MATAMAZOM_SUCCESS;
        }
        Product new_product = copyProductFunction(temp_product_in_container);
        if( !new_product ){
            freeProductFunction(new_product);
            return MATAMAZOM_OUT_OF_MEMORY;
        }
        if( asRegister(getOrderProducts(temp_order), new_product)==AS_SUCCESS ){
            if( asChangeAmount(getOrderProducts(temp_order), new_product, amount)==AS_SUCCESS ){
                freeProductFunction(new_product);
                return MATAMAZOM_SUCCESS;
            }
        }
    }
    double amount_saver = 0;
    asGetAmount(getOrderProducts(temp_order), temp_product_in_order, &amount_saver);
    if( amount<0 && amount+amount_saver<=EPSILON ){
        asDelete(getOrderProducts(temp_order), temp_product_in_order);
        return MATAMAZOM_SUCCESS;
    }
    asChangeAmount(getOrderProducts(temp_order), temp_product_in_order, amount);
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmShipOrder(Matamazom matamazom, const unsigned int orderId){
    if( !matamazom ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    Order temp_order = getOrder(matamazom->orders, orderId);
    if( !temp_order ){
        return MATAMAZOM_ORDER_NOT_EXIST;
    }
    AS_FOREACH(Product, iterator, getOrderProducts(temp_order)){
        double amount_in_container = 0, amount_in_order = 0;
        Product temp_product = getProduct(matamazom->container, getProductId(iterator));
        asGetAmount(matamazom->container, temp_product, &amount_in_container);
        asGetAmount(getOrderProducts(temp_order), iterator, &amount_in_order);
        if( amount_in_container<amount_in_order ){
            return MATAMAZOM_INSUFFICIENT_AMOUNT;
        }
    }
    AS_FOREACH(Product, iterator, matamazom->container) {
        double amount_in_container = 0, amount_in_order = 0;
        Product temp_product = getProduct(matamazom->container, getProductId(iterator));
        asGetAmount(matamazom->container, temp_product, &amount_in_container);
        asGetAmount(getOrderProducts(temp_order), iterator, &amount_in_order);
        double product_profits = getProductProfits(temp_product);
        product_profits += productPrice(temp_product, amount_in_order);
        changeProductProfits(temp_product, product_profits);
        asChangeAmount(matamazom->container, temp_product, (-1)*amount_in_order);
    }
    setRemove(matamazom->orders, temp_order);
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmCancelOrder(Matamazom matamazom, const unsigned int orderId){
    if( !matamazom ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    Order temp_order = getOrder(matamazom->orders, orderId);
    if( !temp_order ){
        return MATAMAZOM_ORDER_NOT_EXIST;
    }
    setRemove(matamazom->orders, temp_order);
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmPrintInventory(Matamazom matamazom, FILE *output){
    if( !matamazom || !output ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    fprintf(output,"Inventory Status:\n");
    double amount_saver = 0;
    AS_FOREACH(Product, iterator, matamazom->container){
        if( asGetAmount(matamazom->container, iterator, &amount_saver)==AS_SUCCESS ){
            mtmPrintProductDetails(getProductName(iterator), getProductId(iterator), amount_saver,
                                   productPrice(iterator, 1), output);
        }
    }
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmPrintOrder(Matamazom matamazom, const unsigned int orderId, FILE *output){
    if( !matamazom || !output ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    Order temp_order = getOrder(matamazom->orders, orderId);
    if( !temp_order ){
        return MATAMAZOM_ORDER_NOT_EXIST;
    }
    mtmPrintOrderHeading(orderId, output);
    double amount_saver = 0, total_sum_for_order = 0, total_price_for_product = 0;
    AS_FOREACH(Product, iterator, getOrderProducts(temp_order)){
        if( asGetAmount(getOrderProducts(temp_order), iterator, &amount_saver)==AS_SUCCESS ){
            total_price_for_product = productPrice(iterator, amount_saver);
            mtmPrintProductDetails(getProductName(iterator), getProductId(iterator), amount_saver, total_price_for_product, output);
            total_sum_for_order += total_price_for_product;
        }
    }
    mtmPrintOrderSummary(total_sum_for_order, output);
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmPrintBestSelling(Matamazom matamazom, FILE *output){
    if( !matamazom || !output ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    double max_profits = 0;
    unsigned int temp_id = 0;
    AS_FOREACH(Product, iterator, matamazom->container){
        if(getProductProfits(iterator)-max_profits<EPSILON && getProductProfits(iterator)-max_profits> -1*EPSILON){
            continue;
        }
        if(getProductProfits(iterator)>max_profits){
            max_profits = getProductProfits(iterator);
            temp_id = getProductId(iterator);
        }
    }
    Product best_selling = getProduct(matamazom->container, temp_id);
    fprintf(output,"Best Selling Product:\n");
    if( !best_selling ){
        fprintf(output,"none\n");
    }
    else{
        mtmPrintIncomeLine(getProductName(best_selling), temp_id, max_profits, output);
    }
    return MATAMAZOM_SUCCESS;
}

MatamazomResult mtmPrintFiltered(Matamazom matamazom, MtmFilterProduct customFilter, FILE *output){
    if( !matamazom || !customFilter || !output ){
        return MATAMAZOM_NULL_ARGUMENT;
    }
    double amount_saver = 0;
    AS_FOREACH(Product, iterator, matamazom->container){
        if( asGetAmount(matamazom->container, iterator, &amount_saver)==AS_SUCCESS ){
            if(customFilter(getProductId(iterator), getProductName(iterator), amount_saver, getProductCustomData(iterator))){
                mtmPrintProductDetails(getProductName(iterator), getProductId(iterator), amount_saver, productPrice(iterator, 1), output);
            }
        }
    }
    return MATAMAZOM_SUCCESS;
}
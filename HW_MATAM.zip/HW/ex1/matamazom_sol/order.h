#ifndef ORDER_ORDER_H
#define ORDER_ORDER_H

#include "matamazom.h"
#include "product.h"
#include "amount_set.h"
#include "set.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct order_t *Order;

/** a function for creating a new order. */
Order createOrderFunction(unsigned int id);

/** a function for coping a existing order. */
void freeOrderFunction(Order to_delete);

/** a function for deallocating an existing order. */
Order copyOrderFunction(Order original_order);

/**
 * a function used to identify equal orders.
 * This function should return:
 *     A positive integer if the first order's id is greater;
 *     0 if they're equal;
 *     A negative integer if the second order's id is greater. */
int compareOrderFunction(Order order1, Order order2);

/** a function for finding an order in a set from it's id. */
Order getOrder(Set set, unsigned int id);

/** a function that returns the order products. */
AmountSet getOrderProducts(Order order);

#endif //ORDER_ORDER_H
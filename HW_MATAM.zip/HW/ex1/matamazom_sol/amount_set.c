#include "amount_set.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct node_t{
    ASElement item;
    double amount_struct;
    struct node_t* next;
} *Node;

struct AmountSet_t{
    Node head;
    int size;
    Node iterator;
    CopyASElement copyElementFunction;
    FreeASElement freeElementFunction;
    CompareASElements compareElementsFunction;
};

/** a function that deallocate an element of the set. */
static void destroyElement(Node to_delete, FreeASElement freeElement);
/** a function that creates a new element */
static Node createNewElement(ASElement element,CopyASElement copyElement);

AmountSet asCreate(CopyASElement copyElement, FreeASElement freeElement, CompareASElements compareElements)
{
    if( !copyElement || !freeElement || !compareElements ){
        return NULL;
    }
    AmountSet set = malloc(sizeof(*set));
    if( !set ){
        return NULL;
    }
    set->head = NULL;
    set->size = 0;
    set->iterator = NULL;
    set->copyElementFunction = copyElement;
    set->freeElementFunction = freeElement;
    set->compareElementsFunction = compareElements;
    return set;
}
static void destroyElement(Node to_delete, FreeASElement freeElement){
    freeElement( to_delete->item );
    free( to_delete );
}
void asDestroy(AmountSet set){
    if(!set)
    {
        free(set);
        return;
    }
    while( set->head ){
        Node to_delete = set->head;
        set->head = set->head->next;
        destroyElement(to_delete, set->freeElementFunction);
    }
    free(set);
}

static Node createNewElement(ASElement element, CopyASElement copyElement){
    if( !element || !copyElement ){
        return NULL;
    }
    Node new_element = malloc(sizeof(*new_element));
    if( !new_element ){
        return NULL;
    }
    new_element->amount_struct = 0;
    new_element->item = copyElement(element);
    new_element->next = NULL;
    return new_element;
}

AmountSet asCopy(AmountSet set)
{
    if( !set ){
        return NULL;
    }
    AmountSet new_set = asCreate(set->copyElementFunction, set->freeElementFunction, set->compareElementsFunction);
    if( !new_set ){
        return NULL;
    }
    Node ptr = set->head;
    while (ptr){
        if( asRegister(new_set, ptr->item) != AS_SUCCESS ){
            asDestroy(new_set);
            return NULL;
        }
        ptr = ptr->next;
    }
    ptr = set->head;
    Node New_Set_ptr = new_set->head;
    while (ptr){
        New_Set_ptr->amount_struct = ptr->amount_struct;
        New_Set_ptr = New_Set_ptr->next;
        ptr = ptr->next;
    }
    return new_set;
}

int asGetSize(AmountSet set){
    if( !set ){
        return -1;
    }
    return set->size;
}

bool asContains(AmountSet set, ASElement element){
    if( !set || !element ){
        return false;
    }
    Node ptr = set->head;
    while(ptr){
        if( set->compareElementsFunction(ptr->item,element)==0 ){
            return true;
        }
        ptr = ptr->next;
    }
    return false;
}
AmountSetResult asGetAmount(AmountSet set, ASElement element, double *outAmount){
    if( !set || !element || !outAmount ){
        return AS_NULL_ARGUMENT;
    }
    if( !asContains(set,element) ){
        return AS_ITEM_DOES_NOT_EXIST;
    }
    Node ptr = set->head;
    while(ptr){
        if( set->compareElementsFunction(ptr->item,element)==0 ){
            *(outAmount) = ptr->amount_struct;
            return AS_SUCCESS;
        }
        ptr = ptr->next;
    }
    return AS_ITEM_DOES_NOT_EXIST;
}

AmountSetResult asRegister(AmountSet set, ASElement element){
    if( !set || !element ){
        return AS_NULL_ARGUMENT;
    }
    if( asContains(set,element) ){
        return AS_ITEM_ALREADY_EXISTS;
    }
    if( set->head==NULL ){
        set->head = createNewElement(element,set->copyElementFunction);
        set->size++;
        return AS_SUCCESS;
    }
    Node new_node = createNewElement(element,set->copyElementFunction);
    if( !new_node )
    {
        return AS_OUT_OF_MEMORY;
    }
    Node ptr = set->head;
    if( ptr==set->head && set->compareElementsFunction(ptr->item,element)>0 ){
        new_node->next = ptr;
        set->head = new_node;
        set->size++;
        return AS_SUCCESS;
    }
    while(ptr){
        if( ptr->next==NULL  &&  set->compareElementsFunction(ptr->item,element)<0 ){
            ptr->next = new_node;
            new_node->next = NULL;
            set->size++;
            return AS_SUCCESS;
        }
        if( (ptr->next != NULL) && ( ( set->compareElementsFunction(ptr->next->item,element) )>0 ) &&
            ( ( set->compareElementsFunction(ptr->item,element) )<0 ) ){
            new_node->next = ptr->next;
            ptr->next = new_node;
            set->size++;
            return AS_SUCCESS;
        }
        ptr = ptr->next;
    }
    return AS_SUCCESS;
}
AmountSetResult asChangeAmount(AmountSet set, ASElement element, const double amount){
    if( !set || !element ){
        return AS_NULL_ARGUMENT;
    }
    if( asContains(set,element)==false ){
        return AS_ITEM_DOES_NOT_EXIST;
    }
    Node ptr = set->head;
    while (ptr){
        if( set->compareElementsFunction(ptr->item,element)==0 ){
            if( ptr->amount_struct+amount<0 ){
                return AS_INSUFFICIENT_AMOUNT;
            }
            ptr->amount_struct = ptr->amount_struct+amount;
            return AS_SUCCESS;
        }
        ptr=ptr->next;
    }
    return AS_ITEM_DOES_NOT_EXIST;
}

AmountSetResult asDelete(AmountSet set, ASElement element){
    if( !set || !element ){
        return AS_NULL_ARGUMENT;
    }
    if( !asContains(set, element) ){
        return AS_ITEM_DOES_NOT_EXIST;
    }
    Node ptr = set->head;
    while(ptr){
        if( ptr==set->head && set->compareElementsFunction(ptr->item,element)==0 ){
            set->head = ptr->next;
            set->size--;
            destroyElement(ptr, set->freeElementFunction);
            return AS_SUCCESS;
        }
        if( ptr->next->next==NULL && set->compareElementsFunction(ptr->item,element)==0 ){
            Node to_delete = ptr->next;
            ptr->next = NULL;
            set->size--;
            destroyElement(to_delete, set->freeElementFunction);
            return AS_SUCCESS;
        }
        if( set->compareElementsFunction(ptr->next->item,element)==0 ){
            Node to_delete = ptr->next;
            ptr->next = to_delete->next;
            set->size--;
            destroyElement(to_delete, set->freeElementFunction);
            return AS_SUCCESS;
        }
        ptr = ptr->next;
    }
    return AS_SUCCESS;
}

AmountSetResult asClear(AmountSet set){
    if( !set ){
        return AS_NULL_ARGUMENT;
    }
    Node ptr = set->head;
    while(ptr){
        Node to_delete = ptr;
        ptr = ptr->next;
        destroyElement(to_delete,set->freeElementFunction);
    }
    set->size = 0;
    set->head = NULL;
    set->iterator = NULL;
    return AS_SUCCESS;
}

ASElement asGetFirst(AmountSet set){
    if( !set || asGetSize(set)==0 ){
        return NULL;
    }
    set->iterator = set->head;
    return set->iterator->item;
}

ASElement asGetNext(AmountSet set){
    if( !set || set->iterator==NULL || set->iterator->next==NULL ){
        return NULL;
    }
    set->iterator = set->iterator->next;
    return set->iterator->item;
}

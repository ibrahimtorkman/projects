#ifndef AMOUNT_SET_H_
#define AMOUNT_SET_H_

#include <stdio.h>
#include <stdbool.h>

/**
 * Generic Amount Set Container
 *
 * Implements a sorted amount set container type.
 * The set has an internal iterator for external use. For all functions
 * where the state of the iterator after calling that function is not stated,
 * it is undefined. That is you cannot assume anything about it.
 * The set is sorted in ascending order - iterating over the set is done in the
 * same order.
 *
 * The following functions are available:
 *   asCreate           - Creates a new empty set
 *   asDestroy          - Deletes an existing set and frees all resources
 *   asCopy             - Copies an existing set
 *   asGetSize          - Returns the size of the set
 *   asContains         - Checks if an element exists in the set
 *   asGetAmount         - Returns the amount of an element in the set
 *   asRegister         - Add a new element into the set
 *   asChangeAmount     - Increase or decrease the amount of an element in the set
 *   asDelete           - Delete an element completely from the set
 *   asClear            - Deletes all elements from target set
 *   asGetFirst         - Sets the internal iterator to the first element
 *                        in the set, and returns it.
 *   asGetNext          - Advances the internal iterator to the next element
 *                        and returns it.
 *   AS_FOREACH         - A macro for iterating over the set's elements
 */
typedef struct AmountSet_t *AmountSet;
typedef enum AmountSetResult_t {
    AS_SUCCESS = 0,
    AS_OUT_OF_MEMORY,
    AS_NULL_ARGUMENT,
    AS_ITEM_ALREADY_EXISTS,
    AS_ITEM_DOES_NOT_EXIST,
    AS_INSUFFICIENT_AMOUNT
} AmountSetResult;

typedef void *ASElement;
typedef ASElement (*CopyASElement)(ASElement);
typedef void (*FreeASElement)(ASElement);
typedef int (*CompareASElements)(ASElement, ASElement);

AmountSet asCreate(CopyASElement copyElement, FreeASElement freeElement, CompareASElements compareElements);
void asDestroy(AmountSet set);
AmountSet asCopy(AmountSet set);
int asGetSize(AmountSet set);
bool asContains(AmountSet set, ASElement element);
AmountSetResult asGetAmount(AmountSet set, ASElement element, double *outAmount);
AmountSetResult asRegister(AmountSet set, ASElement element);
AmountSetResult asChangeAmount(AmountSet set, ASElement element, const double amount);
AmountSetResult asDelete(AmountSet set, ASElement element);
AmountSetResult asClear(AmountSet set);
ASElement asGetFirst(AmountSet set);
ASElement asGetNext(AmountSet set);
#define AS_FOREACH(type, iterator, set)          \
    for(type iterator = (type) asGetFirst(set) ; \
        iterator ;                               \
        iterator = asGetNext(set))

#endif /* AMOUNT_SET_H_ */

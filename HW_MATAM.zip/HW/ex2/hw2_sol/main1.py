from pythonFuncs import correct_myfile

if __name__ == '__main__':
    correct_myfile("survey1")

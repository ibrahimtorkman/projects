import Survey
# Filters a survey and prints to screen the corrected answers:
# old_survey_path: The path to the unfiltered survey
def correct_myfile(old_survey_path):
    f = open(old_survey_path, "r")
    lines_list = []
    new_dict = {}
    ids_list = []
    for i, line in enumerate(f):
        lines_list.append(line.split())
        if len(lines_list[i][0]) != 8 or int(lines_list[i][2]) < 10 or int(lines_list[i][2]) > 100:
            continue
        j = 0
        while j < len(lines_list[i][4:9:1]):
            if int((lines_list[i][4:9:1])[j]) < 1 or int((lines_list[i][4:9:1])[j]) > 10:
                j = 'score not valid'
                break
            else:
                new_dict[lines_list[i][0]] = line
            j += 1
        if j != 'score not valid':
            if lines_list[i][0] in ids_list:
                continue
            else:
                ids_list.append(lines_list[i][0])
    ids_list.sort()
    i = 0
    while i < len(ids_list):
        for keys, variables in new_dict.items():
            if ids_list[i] == keys:
                print(variables[0:len(variables) - 1:1])
        i += 1
    f.close()


# Returns a new Survey item with the data of a new survey file:
# survey_path: The path to the survey
def scan_survey(survey_path):
    s = Survey.SurveyCreateSurvey()
    if not s:
        pass
    f = open(survey_path, "r")
    new_list = []
    i = 0
    for line in f:
        new_list.append(line.split())
        i += 1
    for j in range(i):
        gender = 0
        eating_habit = 0

        chocolate_array = Survey.SurveyCreateIntAr(5)
        for k in range(5):
            Survey.SurveySetIntArIdxVal(chocolate_array, k, int(new_list[j][k + 4]))
        if new_list[j][3] == 'Woman':
            gender = 1
        if new_list[j][1] == 'Vegaterian':
            eating_habit = 1
        if new_list[j][1] == 'Omnivore':
            eating_habit = 2
        Survey.SurveyAddPerson(s, int(new_list[j][0]), int(new_list[j][2]), gender, eating_habit, chocolate_array)
        Survey.SurveyDestoryIntAr(chocolate_array)
    return s


# Prints a python list containing the number of votes for each rating of a group according to the arguments
# s: the data of the Survey object
# choc_type: the number of the chocolate (between 0 and 4)
# gender: the gender of the group (string of "Man" or "Woman")
# min_age: the minimum age of the group (a number)
# max_age: the maximum age of the group (a number)
# eating_habits: the eating habits of the group (string of "Omnivore", "Vegan" or "Vegetarian")
def print_info(s, choc_type, gender, min_age, max_age, eating_habits):
    if eating_habits == 'Vegaterian':
        eating_habits = 1
    elif eating_habits == 'Omnivore':
        eating_habits = 2
    else:
        eating_habits = 0
    if gender == 'Woman':
        gender = 1
    else:
        gender = 0
    query = Survey.SurveyQuerySurvey(s, choc_type, gender, min_age, max_age, eating_habits)
    if not query:
        pass
    new_list = []
    for i in range(10):
        new_list.append(Survey.SurveyGetIntArIdxVal(query, i))
    print(new_list)
    Survey.SurveyQueryDestroy(query)


# Clears a Survey object data
# s: the data of the Survey object
def clear_survey(s):
    Survey.SurveyDestroySurvey(s)
